#!/usr/bin/env python3
"""Q33 focused active AT-SPI bridge: real UI role changes and loss of private access."""
import argparse, hashlib, json, os, pathlib, selectors, signal, socket, subprocess as S, sys, time, traceback
ROOT=pathlib.Path('/home/gyl/example/chat')
p=argparse.ArgumentParser(); p.add_argument('--binary',required=True,type=pathlib.Path); p.add_argument('--expected-sha',required=True); p.add_argument('--output',required=True,type=pathlib.Path)
native=p.parse_args(); work=native.output.resolve(); candidate=native.binary.resolve(strict=True)
qt_prefix=pathlib.Path('/tmp/chat-qt-dependency-compare.dmJWg7/install'); driver_path=pathlib.Path(__file__).resolve()
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(candidate)==native.expected_sha
binary_sha=sha(candidate); driver_sha=sha(driver_path); owned=[]; descendants={}; protected={}; owned_database_created=False; workflow_exit=1; phase='fixture'; events=[]
def identity(pid):
    proc=pathlib.Path('/proc')/str(pid); stat=proc.joinpath('stat').read_text().rsplit(')',1)[1].split()
    return {'pid':pid,'tick':stat[19],'cmdline_hex':proc.joinpath('cmdline').read_bytes().hex(),'exe':str(proc.joinpath('exe').resolve()),'state':stat[0]}
for pid,tick in [(2876288,'521400965'),(3225,'17583'),(29935,'248258')]:
    protected[str(pid)]=identity(pid); assert protected[str(pid)]['tick']==tick
source_paths=sorted((ROOT/'qt/src').glob('*'))+[ROOT/'qt/tests/ui_test.cpp',ROOT/'tests/qt_x11_smoke.py',ROOT/'tests/tui_scale_fixture.cpp',ROOT/'qt/CMakeLists.txt',ROOT/'CMakeLists.txt']
source_start={str(q.relative_to(ROOT)):sha(q) for q in source_paths if q.is_file()}
for name in ['WAYLAND_DISPLAY','IBUS_ADDRESS','IBUS_ADDRESS_FILE','DBUS_SESSION_BUS_ADDRESS','DBUS_STARTER_ADDRESS','DBUS_STARTER_BUS_TYPE','AT_SPI_BUS_ADDRESS','I3SOCK','XAUTHORITY','QT_IM_MODULE','QT_SCALE_FACTOR','QT_PLUGIN_PATH','QT_QPA_PLATFORM_PLUGIN_PATH','LD_LIBRARY_PATH']:
    os.environ.pop(name,None)
os.environ.update(QT_QPA_PLATFORM='xcb',QT_FONT_DPI='96',QT_AUTO_SCREEN_SCALE_FACTOR='0',QT_ENABLE_HIGHDPI_SCALING='0',QT_LINUX_ACCESSIBILITY_ALWAYS_ON='1')
for key,directory in [('XDG_CONFIG_HOME','config'),('XDG_CACHE_HOME','cache'),('XDG_DATA_HOME','data'),('XDG_RUNTIME_DIR','runtime')]: os.environ[key]=str(work/directory)
_run,_output=S.run,S.check_output
def bounded_run(*a,**kw): kw.setdefault('timeout',15); return _run(*a,**kw)
def bounded_output(*a,**kw): kw.setdefault('timeout',15); return _output(*a,**kw)
S.run=bounded_run; S.check_output=bounded_output
def pipe_line(proc,label):
    with selectors.DefaultSelector() as sel:
        sel.register(proc.stdout,selectors.EVENT_READ); assert sel.select(15),label
    value=proc.stdout.readline().strip(); assert value,label; return value
def scrub(v):
    if isinstance(v,dict): return {k:scrub(x) for k,x in v.items() if k not in ['password','invite_token','token','password_hash']}
    if isinstance(v,list): return [scrub(x) for x in v]
    return v
def qt_client_env(alias):
    env=os.environ.copy(); env.update(LD_LIBRARY_PATH=str(qt_prefix/'lib'),QT_PLUGIN_PATH=str(qt_prefix/'plugins'),QT_IM_MODULE='compose',QT_SCALE_FACTOR='1'); return env
smoke_source=(ROOT/'tests/qt_x11_smoke.py').read_text(); prefix=smoke_source.split('def run_scale():')[0]
prefix=prefix.replace('timeout=600','timeout=15').replace('timeout=30','timeout=15').replace('owned = []','owned = [private_bus]')
prefix=prefix.replace('work.mkdir(mode=448, parents=True)','work.mkdir(mode=448, parents=True, exist_ok=True)')
prefix=prefix.replace("str(build / 'qt/chat_qt')",'str(candidate)')
prefix=prefix.replace("display = ':' + xvfb.stdout.readline().strip()", "display = ':' + pipe_line(xvfb,'owned Xvfb display')")
prefix=prefix.replace("stdout=(work / ('qt-' + alias + '.log')).open('w'), stderr=S.STDOUT)","stdout=(work / ('qt-' + alias + '.log')).open('w'), stderr=S.STDOUT, env=qt_client_env(alias))")
prefix=prefix.replace('json.dumps(result, ensure_ascii=False, indent=2)','json.dumps(scrub(result), ensure_ascii=False, indent=2)').replace('json.dumps(manifest, ensure_ascii=False, indent=2)','json.dumps(scrub(manifest), ensure_ascii=False, indent=2)')
prefix=prefix.replace("S.run(['createdb', '--maintenance-db=' + maintenance, '--template=template0', database], check=True)","S.run(['createdb', '--maintenance-db=' + maintenance, '--template=template0', database], check=True)\nowned_database_created = True")
prefix=prefix.replace('for _ in range(150):','server_deadline=time.monotonic()+15\nwhile time.monotonic()<server_deadline:')
def snapshot_descendants(stage):
    table={int(a):int(b) for a,b in (line.split() for line in S.check_output(['ps','-e','-o','pid=,ppid='],text=True).splitlines())}; tree={os.getpid()}
    while True:
        more={pid for pid,parent in table.items() if parent in tree}-tree
        if not more: break
        tree.update(more)
    for pid in tree-{os.getpid()}:
        assert str(pid) not in protected
        try: descendants[str(pid)]=identity(pid)
        except (FileNotFoundError,ProcessLookupError): pass
    (work/('descendants-'+stage+'.json')).write_text(json.dumps(list(descendants.values()),indent=2))
def visit(node,predicate):
    try:
        if node is None or node.getState().contains(pyatspi.STATE_DEFUNCT): return None
        if predicate(node): return node
        for child in node:
            if child:
                found=visit(child,predicate)
                if found: return found
    except Exception: pass
    return None
def client_app(alias):
    for app in pyatspi.Registry.getDesktop(0):
        if app is None: continue
        try:
            if not app.getState().contains(pyatspi.STATE_DEFUNCT) and app.get_process_id()==clients[alias].pid: return app
        except Exception: continue
    return None
def public(predicate,alias='A'):
    return visit(client_app(alias),lambda n:n.getState().contains(pyatspi.STATE_SHOWING) and predicate(n))
    return None
def named(name,role=None,alias='A'): return public(lambda n:n.name==name and (role is None or n.getRole()==role),alias)
def rect(node):
    r=node.queryComponent().getExtents(pyatspi.DESKTOP_COORDS); return [r.x,r.y,r.width,r.height]
def click_node(node,label):
    r=rect(node); assert r[2]>0 and r[3]>0,(label,r)
    (work/'actions.jsonl').open('a').write(json.dumps({'label':label,'role':node.getRoleName(),'name':node.name,'description':node.description,'physical_rect':r},ensure_ascii=False)+'\n')
    click(round(r[0]+r[2]/2),round(r[1]+r[3]/2))
def dump_tree(label,alias='A'):
    rows=[]
    def walk(n,path):
        try:
            if n is None or n.getState().contains(pyatspi.STATE_DEFUNCT): return
            state=n.getState(); showing=state.contains(pyatspi.STATE_SHOWING)
            try: bounds=rect(n) if showing else None
            except NotImplementedError: bounds=None
            rows.append({'path':path,'role':n.getRoleName(),'name':n.name,'description':n.description,'visible':state.contains(pyatspi.STATE_VISIBLE),'showing':showing,'enabled':state.contains(pyatspi.STATE_ENABLED),'sensitive':state.contains(pyatspi.STATE_SENSITIVE),'rect':bounds})
            for i,child in enumerate(n):
                if child: walk(child,path+[i])
        except Exception as error: rows.append({'path':path,'error':str(error)})
    app=client_app(alias)
    assert app is not None,'actual client application missing during tree snapshot'
    walk(app,[])
    (work/(label+'.atspi.json')).write_text(json.dumps(rows,ensure_ascii=False,indent=2)); return rows
def list_rows(name,alias='A',showing=True):
    node=named(name,pyatspi.ROLE_LIST,alias) if showing else any_named(name,pyatspi.ROLE_LIST,alias)
    if node is None: return []
    rows=[]
    for child in node:
        if child and not child.getState().contains(pyatspi.STATE_DEFUNCT) and child.getRole()==pyatspi.ROLE_LIST_ITEM:
            state=child.getState()
            rows.append({'name':child.name,'description':child.description,'role':child.getRoleName(),'showing':state.contains(pyatspi.STATE_SHOWING),'enabled':state.contains(pyatspi.STATE_ENABLED)})
    return rows
def owned_paste(text):
    proc=S.Popen(['/usr/bin/xclip','-quiet','-selection','clipboard','-in'],stdin=S.PIPE,stdout=S.DEVNULL,stderr=(work/'clipboard.log').open('a'),text=True); owned.append(proc); proc.stdin.write(text); proc.stdin.close()
    wait(lambda:S.check_output(['/usr/bin/xclip','-selection','clipboard','-out'],text=True,timeout=1)==text,'owned clipboard ready'); key('v',True); time.sleep(.15)
def runtime(stage,alias='A'):
    proc=pathlib.Path('/proc')/str(clients[alias].pid); assert proc.joinpath('exe').resolve()==candidate and sha(proc.joinpath('exe'))==binary_sha
    libraries=sorted(set(line.split()[-1] for line in proc.joinpath('maps').read_text().splitlines() if '/libQt6' in line or '/plugins/platforms/' in line or '/plugins/platforminputcontexts/' in line))
    assert any('/libQt6Widgets.so.6.5.3' in q for q in libraries) and any('/plugins/platforms/libqxcb.so' in q for q in libraries)
    assert all(pathlib.Path(q).is_relative_to(qt_prefix) for q in libraries)
    (work/('runtime-'+alias+'-'+stage+'.json')).write_text(json.dumps({'actual_process':identity(clients[alias].pid),'binary_sha256':binary_sha,'loaded_qt':[{'path':q,'sha256':sha(pathlib.Path(q))} for q in libraries],'private_bus':identity(private_bus.pid),'display':display,'qt_child_only_loader':True},indent=2)); snapshot_descendants(stage)
def any_named(name,role=None,alias='A'):
    return visit(client_app(alias),lambda n:n.name==name and (role is None or n.getRole()==role))
def group_node(alias='A'):
    return any_named(manifest['group']['title']+' · 群资料',pyatspi.ROLE_DIALOG,alias)
def group_tabs(alias='A'):
    node=group_node(alias); assert node is not None,'actual open group dialog missing'
    bar=visit(node,lambda n:n.getRole()==pyatspi.ROLE_PAGE_TAB_LIST)
    assert bar is not None,'actual group tab list missing'
    return [child.name for child in bar if child and not child.getState().contains(pyatspi.STATE_DEFUNCT) and child.getRole()==pyatspi.ROLE_PAGE_TAB]
def pump_events():
    context=GLib.MainContext.default()
    for _ in range(100):
        if not context.pending(): break
        context.iteration(False)
def accessibility_event(event):
    try:
        pid=event.source.getApplication().get_process_id()
        aliases=[alias for alias,proc in clients.items() if proc.pid==pid]
        if not aliases: return
        value={'monotonic':time.monotonic(),'phase':phase,'actor':aliases[0],'type':event.type,'detail1':event.detail1,'detail2':event.detail2,'source_name':event.source.name,'source_role':event.source.getRoleName()}
        events.append(value)
        (work/'bridge-events.jsonl').open('a').write(json.dumps(value,ensure_ascii=False)+'\n')
    except Exception as error:
        (work/'bridge-event-errors.jsonl').open('a').write(json.dumps({'phase':phase,'type':event.type,'error':str(error)})+'\n')
def role_fact():
    result=sql("SELECT u.id,encode(convert_to(u.username,'UTF8'),'hex'),CASE WHEN c.owner_id=cm.user_id THEN 'owner' WHEN cm.is_admin THEN 'admin' ELSE 'member' END FROM conversation_members cm JOIN conversations c ON c.id=cm.conversation_id JOIN users u ON u.id=cm.user_id WHERE cm.conversation_id="+str(room)+' ORDER BY u.id')
    return [{'user':int(uid),'username':bytes.fromhex(name).decode('utf-8'),'role':role} for uid,name,role in (line.split('|') for line in result.splitlines())]
def roles(): return {q['user']:q['role'] for q in role_fact()}
def pending_fact():
    return sql('SELECT count(*) FROM group_join_requests WHERE conversation_id='+str(room)+' AND user_id='+str(actor('D')['id']))
def expected_names(alias,expected_roles):
    labels={'owner':'群主','admin':'管理员','member':'成员'}
    return {actor(other)['username']+' · '+labels[role]+(' · 你' if other==alias else '') for other,role in expected_roles.items()}
def rows_match(alias,list_name,expected):
    try:
        values=list_rows(list_name,alias)
        return {q['name'] for q in values}==expected and all(q['showing'] for q in values)
    except Exception: return False
def show_tab(alias,prefix_name):
    focus(modal(alias,'群资料'))
    tab=wait(lambda:public(lambda n:n.getRole()==pyatspi.ROLE_PAGE_TAB and n.name.startswith(prefix_name),alias),'real '+alias+' '+prefix_name+' tab')
    click_node(tab,alias+' show '+prefix_name)
def menu_action(alias,target,action):
    focus(modal(alias,'群资料'))
    member_list=wait(lambda:named('群成员',pyatspi.ROLE_LIST,alias),'actual '+alias+' member list')
    node=wait(lambda:visit(member_list,lambda n:n.getRole()==pyatspi.ROLE_LIST_ITEM and n.name.startswith(actor(target)['username']+' · ')),'actual '+alias+' target member '+target)
    r=rect(node)
    (work/'actions.jsonl').open('a').write(json.dumps({'label':alias+' context menu '+target,'role':node.getRoleName(),'name':node.name,'physical_rect':r},ensure_ascii=False)+'\n')
    xt.XTestFakeMotionEvent(d,-1,round(r[0]+r[2]/2),round(r[1]+r[3]/2),0)
    xt.XTestFakeButtonEvent(d,3,1,0); xt.XTestFakeButtonEvent(d,3,0,0); x.XFlush(d)
    time.sleep(.2); pump_events()
    (work/('menu-'+phase+'.xwininfo.txt')).write_text(windows())
    menu_tree=dump_tree('menu-'+phase,alias); capture('menu-'+phase+'-fullscreen')
    item=named(action,pyatspi.ROLE_MENU_ITEM,alias)
    menu_observation={'label':alias+' '+action+' '+target+' through UI','phase':phase,'target':target,'requested_action':action,'public_menu_items':[q['name'] for q in menu_tree if q.get('role')=='menu item' and q.get('showing')],'public_action_found':item is not None}
    if item is not None:
        assert item.getState().contains(pyatspi.STATE_ENABLED)
        menu_observation['input']='XTest click on public menu item'; click_node(item,menu_observation['label'])
    else:
        current=roles(); is_admin=current[actor(target)['id']]=='admin'
        order=['个人资料','取消管理员' if is_admin else '设为管理员']+(['转让群主'] if is_admin else [])+['移除成员']
        assert action in order
        menu_observation.update(input='XTest Down/Return through actual native menu; not a business call',source_defined_order=order,down_count=order.index(action)+1,accessibility_boundary='Actual popup is captured; no menu item in this public app tree. Not certified as accessible menu.')
        for _ in range(order.index(action)+1): key('Down'); time.sleep(.08)
        key('Return')
    (work/'menu-observations.jsonl').open('a').write(json.dumps(menu_observation,ensure_ascii=False)+'\n')
def snapshot(label):
    pump_events()
    facts={'label':label,'sql_roles':role_fact(),'sql_pending_D':pending_fact(),'actors':{},'event_count':len(events)}
    for alias in ['A','B']:
        facts['actors'][alias]={'pid':clients[alias].pid,'members':list_rows('群成员',alias,False),'preview':list_rows('群成员预览',alias,False),'requests':list_rows('待处理入群申请',alias,False)}
        dump_tree(label+'-'+alias,alias)
    facts['whole_png']=capture(label+'-fullscreen')
    (work/(label+'.json')).write_text(json.dumps(facts,ensure_ascii=False,indent=2)); return facts
try:
    work.mkdir(mode=0o700,parents=True,exist_ok=True)
    for directory in ['config','cache','data','runtime']: work.joinpath(directory).mkdir(mode=0o700)
    with socket.socket() as probe: probe.bind(('127.0.0.1',0)); port=probe.getsockname()[1]
    private_bus=S.Popen(['/usr/bin/dbus-daemon','--session','--nofork','--print-address=1','--nosyslog'],stdout=S.PIPE,stderr=(work/'dbus.log').open('w'),text=True); owned.append(private_bus)
    os.environ['DBUS_SESSION_BUS_ADDRESS']=pipe_line(private_bus,'private bus address')
    sys.argv=[str(ROOT/'tests/qt_x11_smoke.py'),'--build',str(ROOT/'build'),'--port',str(port),'--output',str(work),'--navigation-only']; __file__=str(ROOT/'tests/qt_x11_smoke.py')
    exec(compile(prefix,__file__,'exec'),globals())
    with (work/'private-bus-activation-environment.log').open('w') as log: S.run(['/usr/bin/dbus-update-activation-environment','DISPLAY','XDG_RUNTIME_DIR','XDG_CONFIG_HOME','XDG_CACHE_HOME','XDG_DATA_HOME'],stdout=log,stderr=S.STDOUT,check=True)
    import pyatspi
    from gi.repository import GLib
    base_wait=wait
    def wait(predicate,label,timeout=15):
        def with_events(): pump_events(); return predicate()
        return base_wait(with_events,label,timeout)
    pyatspi.Registry.registerEventListener(accessibility_event,'object','window')
    paste=owned_paste
    control('connect',actors=['A','D'])
    room=manifest['group']['id']
    assert control('sdk',actor='A',method='set_group_admin',conversation=room,user=actor('B')['id'],admin=True)['ok']
    assert control('sdk',actor='A',method='set_group_join_approval',conversation=room,required=True)['ok']
    pending=control('sdk',actor='D',method='join_group',token=manifest['invite_token']); assert pending['ok'] and pending['value']['state']=='pending'
    members_fact=control('sdk',actor='A',method='get_members',conversation=room); assert members_fact['ok']
    control('close'); helper.stdin.close(); helper.wait(timeout=15); assert helper.returncode==0
    (work/'fixture-closed.json').write_text(json.dumps({'pid':helper.pid,'exit':helper.returncode,'room':room,'members':members_fact['value']},ensure_ascii=False,indent=2))
    for alias,offset in [('A',0),('B',1200)]:
        main=login(alias,offset)
        sidebar=wait(lambda:named('会话列表',pyatspi.ROLE_LIST,alias),'real '+alias+' authenticated conversation list'); runtime('authenticated',alias)
        row=wait(lambda:visit(sidebar,lambda n:n.getRole()==pyatspi.ROLE_LIST_ITEM and manifest['group']['title'] in n.name),'real '+alias+' group row'); click_node(row,alias+' open real group')
        header=wait(lambda:named(manifest['group']['title'],pyatspi.ROLE_PUSH_BUTTON,alias),'real '+alias+' group header'); click_node(header,alias+' open group details')
        group=modal(alias,'群资料'); focus(group)
        wait(lambda:named('群成员预览',pyatspi.ROLE_LIST,alias),'real '+alias+' overview preview')
    phase='initial'; expected={'A':'owner','B':'admin','C':'member'}
    for alias in ['A','B']: wait(lambda alias=alias:rows_match(alias,'群成员预览',expected_names(alias,expected)),'initial public preview roles '+alias)
    initial=snapshot('01-initial-open-overviews'); assert pending_fact()=='1'; record('initial-preview-role-self-name',initial)
    show_tab('A','成员'); phase='promote-C'
    menu_action('A','C','设为管理员')
    wait(lambda:roles().get(actor('C')['id'])=='admin','SQL real C promotion')
    expected={'A':'owner','B':'admin','C':'admin','S005':'member'}
    wait(lambda:rows_match('A','群成员',expected_names('A',expected)),'active member Names after C promotion')
    wait(lambda:rows_match('B','群成员预览',expected_names('B',{q:r for q,r in expected.items() if q!='S005'})),'already-open overview Names after C promotion')
    promoted=snapshot('02-C-promoted-active-rows'); record('active-bridge-role-promotion',promoted)
    phase='demote-C'; menu_action('A','C','取消管理员')
    wait(lambda:roles().get(actor('C')['id'])=='member','SQL real C demotion')
    expected['C']='member'
    wait(lambda:rows_match('A','群成员',expected_names('A',expected)),'active member Names after C demotion')
    wait(lambda:rows_match('B','群成员预览',expected_names('B',{q:r for q,r in expected.items() if q!='S005'})),'already-open overview Names after C demotion')
    demoted=snapshot('03-C-demoted-active-rows'); record('active-bridge-role-demotion',demoted)
    phase='transfer-owner'; menu_action('A','B','转让群主')
    focus(modal('A','转让群主'))
    confirm=wait(lambda:named('转让群主',pyatspi.ROLE_PUSH_BUTTON,'A'),'actual transfer confirmation')
    click_node(confirm,'A confirms owner transfer to B through UI')
    wait(lambda:roles().get(actor('B')['id'])=='owner' and roles().get(actor('A')['id'])=='admin','SQL actual owner transfer')
    expected.update(A='admin',B='owner')
    wait(lambda:rows_match('A','群成员',expected_names('A',expected)),'active A member Names after owner transfer')
    wait(lambda:rows_match('B','群成员预览',expected_names('B',{q:r for q,r in expected.items() if q!='S005'})),'already-open B overview Names after owner transfer')
    transferred=snapshot('04-owner-transferred-active-rows'); record('active-bridge-owner-transfer',transferred)
    show_tab('A','入群申请'); phase='private-request-visible'
    wait(lambda:{q['name'] for q in list_rows('待处理入群申请','A')}=={actor('D')['username']+' · 待审批'},'actual private pending Name visible')
    request_node=wait(lambda:public(lambda n:n.getRole()==pyatspi.ROLE_LIST_ITEM and n.name==actor('D')['username']+' · 待审批','A'),'actual D request')
    click_node(request_node,'A selects private D request')
    for action in ['通过申请','拒绝申请']: assert named(action,pyatspi.ROLE_PUSH_BUTTON,'A').getState().contains(pyatspi.STATE_ENABLED)
    private=snapshot('05-A-private-request-before-loss'); record('private-request-Name-status-before-loss',private)
    show_tab('B','成员'); phase='lose-A-manager'
    menu_action('B','A','取消管理员')
    wait(lambda:roles().get(actor('A')['id'])=='member','SQL A truly loses manager permission')
    (work/'06-loss-authoritative-sql.json').write_text(json.dumps({'sql_roles':role_fact(),'sql_pending_D':pending_fact()},ensure_ascii=False,indent=2))
    def private_cleared():
        rows=list_rows('待处理入群申请','A',False)
        dialog=group_node('A')
        if dialog is None: return False
        private_tab=visit(dialog,lambda n:n.getRole()==pyatspi.ROLE_PAGE_TAB and (n.name.startswith('入群申请') or n.name=='管理'))
        visible_action=visit(dialog,lambda n:n.getState().contains(pyatspi.STATE_SHOWING) and n.getRole()==pyatspi.ROLE_PUSH_BUTTON and n.name in ['通过申请','拒绝申请','加载更多申请','群管理'])
        return not rows and private_tab is None and visible_action is None
    wait(private_cleared,'active bridge removes A private request rows/tabs/actions after remote downgrade')
    expected['A']='member'
    show_tab('A','成员')
    wait(lambda:rows_match('A','群成员',expected_names('A',expected)),'A own public member Name after permission loss')
    wait(lambda:rows_match('B','群成员',expected_names('B',expected)),'B public member Name after A permission loss')
    lost=snapshot('06-A-permission-lost-private-cleared')
    tree=dump_tree('06-A-private-including-hidden','A')
    group_path=next(q['path'] for q in tree if q.get('role')=='dialog' and q.get('name')==manifest['group']['title']+' · 群资料')
    group_tree=[q for q in tree if q['path'][:len(group_path)]==group_path]
    assert group_tabs('A')==['群资料','成员'],'private tabs must actually be absent, not merely have empty geometry or hidden flags'
    assert not any(actor('D')['username'] in q.get('name','') or actor('D')['username'] in q.get('description','') for q in group_tree),'private applicant leaked in current active group dialog bridge subtree after loss'
    for action in ['通过申请','拒绝申请','加载更多申请','保存群名','创建链接','复制链接','撤销链接','从联系人邀请']:
        node=any_named(action,pyatspi.ROLE_PUSH_BUTTON,'A')
        assert node is None or not node.getState().contains(pyatspi.STATE_ENABLED),('private action enabled after manager loss',action)
    assert pending_fact()=='1','permission downgrade must not accept/reject pending D'
    record('remote-manager-loss-clears-private-bridge-and-disables-actions',lost)
    phase='loss-context-menu'
    member_list=wait(lambda:named('群成员',pyatspi.ROLE_LIST,'A'),'actual A member list after loss')
    target=wait(lambda:visit(member_list,lambda n:n.getRole()==pyatspi.ROLE_LIST_ITEM and n.name.startswith(actor('C')['username']+' · ')),'A visible C member after loss')
    r=rect(target); focus(modal('A','群资料'))
    xt.XTestFakeMotionEvent(d,-1,round(r[0]+r[2]/2),round(r[1]+r[3]/2),0); xt.XTestFakeButtonEvent(d,3,1,0); xt.XTestFakeButtonEvent(d,3,0,0); x.XFlush(d)
    time.sleep(.2); pump_events()
    (work/'07-A-downgraded-context-menu.xwininfo.txt').write_text(windows())
    menu_tree=dump_tree('07-A-downgraded-context-menu','A')
    actions=[q['name'] for q in menu_tree if q.get('role')=='menu item' and q.get('showing')]
    assert not actions or actions==['个人资料'],('downgraded public context menu actions',actions)
    capture('07-A-downgraded-context-menu-fullscreen'); key('Escape')
    phase='restore-A-manager'
    menu_action('B','A','设为管理员')
    wait(lambda:roles().get(actor('A')['id'])=='admin','SQL A truly regains manager permission')
    expected['A']='admin'
    wait(lambda:rows_match('A','群成员',expected_names('A',expected)),'A public member Names after real permission restoration')
    wait(lambda:rows_match('B','群成员',expected_names('B',expected)),'B public member Names after real A permission restoration')
    wait(lambda:group_tabs('A')==['群资料','成员','入群申请 (1)','管理'],'real restored tabs in original order with authoritative current request count')
    restored=snapshot('08-A-management-restored-public-members')
    assert pending_fact()=='1'
    show_tab('A','入群申请')
    wait(lambda:{q['name'] for q in list_rows('待处理入群申请','A')}=={actor('D')['username']+' · 待审批'},'fresh request list really present after restored authorization')
    restored_requests=snapshot('09-A-restored-private-fresh-request')
    request_node=wait(lambda:public(lambda n:n.getRole()==pyatspi.ROLE_LIST_ITEM and n.name==actor('D')['username']+' · 待审批','A'),'real restored D request')
    click_node(request_node,'A selects fresh restored D request')
    for action in ['通过申请','拒绝申请']: assert named(action,pyatspi.ROLE_PUSH_BUTTON,'A').getState().contains(pyatspi.STATE_ENABLED)
    show_tab('A','群资料')
    click_node(wait(lambda:named('群管理',pyatspi.ROLE_PUSH_BUTTON,'A'),'real restored overview management action'),'A opens restored management page through overview action')
    def management_title_visible():
        node=named('群名称',pyatspi.ROLE_TEXT,'A')
        return node is not None and node.getState().contains(pyatspi.STATE_ENABLED) and node.queryText().getText(0,-1)==manifest['group']['title']
    wait(management_title_visible,'real management title input with actual text role and literal value after identity navigation')
    snapshot('10-A-restored-management-navigation')
    show_tab('A','成员')
    phase='restored-repeat-promote-C'; menu_action('B','C','设为管理员')
    wait(lambda:roles().get(actor('C')['id'])=='admin','SQL repeated actual C promotion after restoration')
    expected['C']='admin'
    wait(lambda:rows_match('A','群成员',expected_names('A',expected)),'live A Names after repeated manager snapshot')
    wait(lambda:rows_match('B','群成员',expected_names('B',expected)),'live B Names after repeated manager snapshot')
    assert group_tabs('A')==['群资料','成员','入群申请 (1)','管理'],'repeated authoritative role updates must not duplicate private tabs'
    repeat=snapshot('11-restored-no-duplicate-tabs-live-role-update')
    record('remote-manager-restoration-refreshes-private-pages-without-duplicates',{'restored':restored,'requests':restored_requests,'repeated':repeat})
    for alias in ['A','B']: runtime('after-permission-restoration',alias)
    pump_events()
    live_events=[q for q in events if q['phase'] in ['promote-C','demote-C','transfer-owner','lose-A-manager','restore-A-manager','restored-repeat-promote-C']]
    assert live_events,'registered active bridge emitted no public live events'
    relevant=[q for q in live_events if q['source_name'] in ['群成员','群成员预览','待处理入群申请'] or ' · 群主' in q['source_name'] or ' · 管理员' in q['source_name'] or ' · 成员' in q['source_name']]
    (work/'actual-result.json').write_text(json.dumps({'scope':'Q33 focused real UI administrator role promotion/demotion, owner transfer, remote manager loss and restoration, active public AT-SPI Names and notifications, read-only SQL, whole PNG.','binary':str(candidate),'binary_sha256':binary_sha,'driver_sha256':driver_sha,'shared_smoke_sha256':hashlib.sha256(smoke_source.encode()).hexdigest(),'max_wait_seconds':15,'role_name_updates_pass':True,'owner_transfer_pass':True,'private_request_loss_pass':True,'private_tabs_really_absent_after_loss':True,'private_request_restoration_pass':True,'restored_private_tab_order_and_no_duplicates_pass':True,'downgraded_public_menu_actions':actions,'menu_boundary':'An empty public menu-item set is not proof of the visible menu content; original native menu PNG must be reviewed. Visible menu not certified as AT-SPI accessible.','pending_D_unchanged':True,'active_bridge_live_event_count':len(live_events),'live_role_list_related_events':relevant,'no_manual_accessibility_cache_clear':True,'no_business_sdk_after_fixture_closed':True,'scope_limits':'Single requested scale1/Xvfb2400x1000; not four DPI, Orca speech, whole product or full gate.'},ensure_ascii=False,indent=2))
    workflow_exit=0
except BaseException as error:
    if 'display' in globals():
        try:
            capture('failure-fullscreen')
            for alias in clients: dump_tree('failure-'+alias,alias)
        except Exception: pass
    (work/'failure.json').write_text(json.dumps({'phase':phase,'type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()},ensure_ascii=False,indent=2))
finally:
    if 'private_bus' in globals(): snapshot_descendants('cleanup-before')
    for proc in reversed(owned):
        if proc.poll() is None:
            proc.terminate()
            try: proc.wait(timeout=15)
            except S.TimeoutExpired: proc.kill(); proc.wait(timeout=15)
    def still_own(info):
        try:
            now=identity(info['pid']); return now['tick']==info['tick'] and now['cmdline_hex']==info['cmdline_hex'] and now['state']!='Z'
        except (FileNotFoundError,ProcessLookupError): return False
    for info in reversed(list(descendants.values())):
        if still_own(info): assert str(info['pid']) not in protected; os.kill(info['pid'],signal.SIGTERM)
    deadline=time.monotonic()+15
    while any(still_own(q) for q in descendants.values()) and time.monotonic()<deadline: time.sleep(.1)
    for info in descendants.values():
        if still_own(info): os.kill(info['pid'],signal.SIGKILL)
    db_absent=False
    if owned_database_created:
        S.run(['dropdb','--maintenance-db='+maintenance,database],check=True)
        env=os.environ.copy(); env.update(PGDATABASE=maintenance,PGOPTIONS='-c default_transaction_read_only=on')
        db_absent=S.check_output(['psql','-X','-A','-t','-v','ON_ERROR_STOP=1','-c',"SELECT count(*) FROM pg_database WHERE datname='"+database+"'"],env=env,text=True).strip()=='0'
    unchanged=all(identity(int(pid))['tick']==q['tick'] and identity(int(pid))['cmdline_hex']==q['cmdline_hex'] for pid,q in protected.items())
    all_gone=all(not still_own(q) for q in descendants.values())
    source_end={path:sha(ROOT/path) for path in source_start}; sources_unchanged=source_end==source_start
    (work/'source-inputs.json').write_text(json.dumps({'start':source_start,'end':source_end,'unchanged':sources_unchanged},indent=2))
    with socket.socket() as probe: port_closed=probe.connect_ex(('127.0.0.1',globals().get('port',1)))!=0
    (work/'cleanup.json').write_text(json.dumps({'workflow_exit':workflow_exit,'database':globals().get('database'),'database_absent':db_absent,'private_port_closed':port_closed,'all_owned_gone':all_gone,'owned':[{'pid':v.pid,'exit':v.poll()} for v in owned],'descendants':list(descendants.values()),'protected_expected_and_unchanged':protected,'protected_unchanged':unchanged},indent=2))
    assert all_gone and db_absent and unchanged and port_closed and sources_unchanged
    (work/'artifact-sha256.json').write_text(json.dumps({p.name:sha(p) for p in sorted(work.iterdir()) if p.is_file() and p.name!='artifact-sha256.json'},indent=2))
print(json.dumps({'status':'PASS' if workflow_exit==0 else 'FAIL','work':str(work),'driver_exit':workflow_exit}),flush=True)
sys.exit(workflow_exit)
