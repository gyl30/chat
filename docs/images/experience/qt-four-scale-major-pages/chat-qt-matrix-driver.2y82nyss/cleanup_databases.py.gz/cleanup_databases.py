import json,os,re,subprocess
from pathlib import Path

roots=[Path('/tmp/chat-daily-native-qt-scale'+name+'-2y82nyss') for name in
    ['100','125','125-r2','125-r3','100-r2','150','200','200-r2']]
driver=Path('/tmp/chat-qt-matrix-driver.2y82nyss')
def run(command,environment):
    return subprocess.run(command,env=environment,text=True,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15).stdout.strip()
def ticks(pid):
    return (Path('/proc')/str(pid)/'stat').read_text().rsplit(')',1)[1].split()[19]
protected={2876288:'521400965',3225:'17583',29935:'248258'}
assert all(ticks(pid)==value for pid,value in protected.items())
read_environment=os.environ.copy()
read_environment['PGDATABASE']=os.environ.get('PGDATABASE','postgres')
read_environment['PGOPTIONS']='-c default_transaction_read_only=on'
write_environment=read_environment.copy()
write_environment.pop('PGOPTIONS')
results=[]
for root in roots:
    cleanup=json.loads((root/'cleanup.json').read_text())
    assert cleanup['errors']==[] and cleanup['protected_unchanged'] is True
    assert all(v['gone'] is True for v in cleanup['owned']+cleanup['activation_descendants'])
    database=cleanup['database_retained']
    if database is None:
        results.append({'scope':str(root),'database_created':False,'original_cleanup_status':cleanup['status']})
        continue
    assert re.fullmatch('chat_daily_[0-9a-f]{16}',database)
    statement="SELECT count(*) FROM pg_stat_activity WHERE datname='"+database+"'"
    count=run(['psql','-X','-A','-t','-v','ON_ERROR_STOP=1','-c',statement],read_environment)
    assert count=='0'
    run(['dropdb','--maintenance-db='+read_environment['PGDATABASE'],database],write_environment)
    exists=run(['psql','-X','-A','-t','-v','ON_ERROR_STOP=1','-c',"SELECT count(*) FROM pg_database WHERE datname='"+database+"'"],read_environment)
    assert exists=='0'
    results.append({'scope':str(root),'database':database,'connections_before_drop':0,'dropdb_actual_exit':0,'database_remaining':0})
listeners=run(['ss','-ltnH','sport','=','18962'],os.environ.copy())
assert listeners==''
assert all(ticks(pid)==value for pid,value in protected.items())
proof={'results':results,'protected_ticks_unchanged':True,'private_port_listener_remaining':0,
    'scope':'Only this driver’s eight exact scopes; no other test database or service touched'}
(driver/'final-database-cleanup.json').write_text(json.dumps(proof,indent=2))
print(json.dumps({'scope_count':len(results),'dropped':sum('dropdb_actual_exit' in v for v in results),'remaining':0}),flush=True)
