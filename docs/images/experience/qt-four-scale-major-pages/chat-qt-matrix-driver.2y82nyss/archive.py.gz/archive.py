import gzip,hashlib,json,os,re,subprocess
from pathlib import Path

roots=[Path('/tmp/chat-daily-native-qt-scale'+name+'-2y82nyss') for name in
    ['100','125','125-r2','125-r3','100-r2','150','200','200-r2']]
driver=Path('/tmp/chat-qt-matrix-driver.2y82nyss')
output=Path('/tmp/chat-qt-matrix-archive.2y82nyss')
assert not output.exists()
assert all(p.parent==Path('/tmp') and p.is_dir() and not p.is_symlink() for p in roots+[driver])
assert subprocess.check_output(['git','-C','/home/gyl/example/chat','rev-parse','HEAD'],text=True).strip()=='7375815f70e3d9d6f456c3d9a0d173411800f294'
assert not subprocess.check_output(['git','-C','/home/gyl/example/chat','status','--porcelain'],text=True).strip()
output.mkdir(mode=0o700)
records=[]
for root in roots+[driver]:
    folder=output/root.name
    folder.mkdir()
    for source in sorted(root.iterdir()):
        if not source.is_file() or source.is_symlink(): continue
        data=source.read_bytes()
        target=folder/(source.name if source.suffix=='.png' else source.name+'.gz')
        target.write_bytes(data if source.suffix=='.png' else gzip.compress(data,mtime=0))
        recovered=target.read_bytes() if source.suffix=='.png' else gzip.decompress(target.read_bytes())
        assert recovered==data
        records.append({'source':str(source),'archive':str(target.relative_to(output)),
            'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
            'stored_sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
(output/'archive-proof.json').write_text(json.dumps({'head':'7375815f70e3d9d6f456c3d9a0d173411800f294',
    'status':'ORIGINAL_BYTES_ARCHIVED_NOT_PRODUCT_PASS','count':len(records),'roundtrip_differences':0,
    'top_level_regular_files_only':True,'excluded':'Private runtime/config/cache directories and sockets',
    'records':records},ensure_ascii=False,indent=2))
print(json.dumps({'archive':str(output),'records':len(records),'roundtrip_differences':0}),flush=True)
