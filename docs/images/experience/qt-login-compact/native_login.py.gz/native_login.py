import ctypes as C
import json
import os
from pathlib import Path
import re
import subprocess as S
import sys
import time
from PIL import ImageGrab

out = Path(sys.argv[1])
out.mkdir(exist_ok=False)
base = '/tmp/chat-qt-dependency-compare.dmJWg7/install'
for scale in ('1', '1.25', '1.5', '2'):
    owned = []
    try:
        with (out / ('xvfb-' + scale + '.log')).open('w') as log:
            xvfb = S.Popen(['Xvfb', '-displayfd', '1', '-screen', '0', '2400x1600x24',
                            '-nolisten', 'tcp'], stdout=S.PIPE, stderr=log, text=True)
        owned.append(xvfb)
        display = ':' + xvfb.stdout.readline().strip()
        env = dict(os.environ, DISPLAY=display, QT_QPA_PLATFORM='xcb',
                   QT_SCALE_FACTOR=scale, QT_IM_MODULE='compose', QT_ACCESSIBILITY='0',
                   NO_AT_BRIDGE='1', LD_LIBRARY_PATH=base + '/lib',
                   QT_PLUGIN_PATH=base + '/plugins')
        with (out / ('qt-' + scale + '.log')).open('w') as log:
            qt = S.Popen(['/home/gyl/example/chat/build/qt/chat_qt',
                          'ws://127.0.0.1:18999/ws'], env=env, stdout=log, stderr=log)
        owned.append(qt)
        deadline = time.monotonic() + 15
        while True:
            tree = S.check_output(['xwininfo', '-root', '-tree'], env=env, text=True, timeout=15)
            found = re.search(r'(0x[0-9a-f]+) "Chat"', tree)
            if found:
                break
            assert qt.poll() is None and time.monotonic() < deadline
            time.sleep(.1)
        window = found.group(1)
        info = S.check_output(['xwininfo', '-id', window], env=env, text=True, timeout=15)
        values = [int(re.search(label + r':\s*(-?\d+)', info).group(1)) for label in
                  ('Absolute upper-left X', 'Absolute upper-left Y', 'Width', 'Height')]
        x0, y0, width, height = values
        assert (width, height) == (round(460 * float(scale)), round(600 * float(scale))), values
        time.sleep(.3)
        ImageGrab.grab(xdisplay=display).save(out / ('desktop-' + scale + '.png'))
        ImageGrab.grab(xdisplay=display).crop((x0, y0, x0 + width, y0 + height)).save(
            out / ('login-' + scale + '.png'))
        (out / ('geometry-' + scale + '.json')).write_text(json.dumps(
            dict(scale=scale, pid=qt.pid, geometry=values, window=window), indent=2))
        if scale == '1':
            xlib = C.CDLL('libX11.so.6')
            xt = C.CDLL('libXtst.so.6')
            xlib.XOpenDisplay.argtypes = [C.c_char_p]
            xlib.XOpenDisplay.restype = C.c_void_p
            d = xlib.XOpenDisplay(display.encode())
            xlib.XFlush.argtypes = [C.c_void_p]
            xlib.XCloseDisplay.argtypes = [C.c_void_p]
            xt.XTestFakeMotionEvent.argtypes = [C.c_void_p, C.c_int, C.c_int, C.c_int, C.c_ulong]
            xt.XTestFakeButtonEvent.argtypes = [C.c_void_p, C.c_uint, C.c_int, C.c_ulong]
            # Coordinates are recorded for human review, not a product API.
            click = (x0 + 390, y0 + 95)
            xt.XTestFakeMotionEvent(d, -1, *click, 0)
            xt.XTestFakeButtonEvent(d, 1, 1, 0)
            xt.XTestFakeButtonEvent(d, 1, 0, 0)
            xlib.XFlush(d)
            time.sleep(.3)
            ImageGrab.grab(xdisplay=display).crop((x0, y0, x0 + width, y0 + height)).save(
                out / 'settings-click.png')
            xlib.XCloseDisplay(d)
    finally:
        for p in reversed(owned):
            if p.poll() is None:
                p.terminate()
                try:
                    p.wait(timeout=15)
                except S.TimeoutExpired:
                    p.kill()
                    p.wait(timeout=15)
print('NATIVE_LOGIN_GEOMETRY_PASS scales=1,1.25,1.5,2')
