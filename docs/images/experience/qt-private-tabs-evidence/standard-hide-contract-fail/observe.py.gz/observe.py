#!/usr/bin/env python3
"""Pure standard Qt active AT-SPI/XTest contract probe; no DB or Chat business calls."""
import argparse, ctypes as C, hashlib, json, os, pathlib, re, selectors, signal, socket, subprocess as S, sys, time, traceback
from PIL import ImageGrab

p=argparse.ArgumentParser(); p.add_argument('--binary',required=True,type=pathlib.Path); p.add_argument('--output',required=True,type=pathlib.Path)
args=p.parse_args(); binary=args.binary.resolve(strict=True); work=args.output.resolve(); prefix=pathlib.Path('/tmp/chat-qt-dependency-compare.dmJWg7/install')
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
owned=[]; identities={}; protected={}; events=[]; phase='setup'; exit_code=1
def identity(pid):
    proc=pathlib.Path('/proc')/str(pid); stat=proc.joinpath('stat').read_text().rsplit(')',1)[1].split()
    return {'pid':pid,'tick':stat[19],'cmdline_hex':proc.joinpath('cmdline').read_bytes().hex(),'exe':str(proc.joinpath('exe').resolve()),'state':stat[0]}
for pid,tick in [(2876288,'521400965'),(3225,'17583'),(29935,'248258')]:
    protected[str(pid)]=identity(pid); assert protected[str(pid)]['tick']==tick
observer_identity=identity(os.getpid())
repo=pathlib.Path('/home/gyl/example/chat')
source_paths=sorted((repo/'qt/src').glob('*'))+[repo/'qt/tests/ui_test.cpp',repo/'tests/verify.sh',repo/'qt/CMakeLists.txt',repo/'CMakeLists.txt']
source_start={str(q.relative_to(repo)):sha(q) for q in source_paths if q.is_file()}
for name in ['WAYLAND_DISPLAY','IBUS_ADDRESS','IBUS_ADDRESS_FILE','DBUS_SESSION_BUS_ADDRESS','DBUS_STARTER_ADDRESS','DBUS_STARTER_BUS_TYPE','AT_SPI_BUS_ADDRESS','I3SOCK','XAUTHORITY','QT_IM_MODULE','QT_SCALE_FACTOR','QT_PLUGIN_PATH','QT_QPA_PLATFORM_PLUGIN_PATH','LD_LIBRARY_PATH']:
    os.environ.pop(name,None)
_run,_output=S.run,S.check_output
def bounded_run(*a,**kw): kw.setdefault('timeout',15); return _run(*a,**kw)
def bounded_output(*a,**kw): kw.setdefault('timeout',15); return _output(*a,**kw)
S.run=bounded_run; S.check_output=bounded_output
def line(proc,label):
    with selectors.DefaultSelector() as sel:
        sel.register(proc.stdout,selectors.EVENT_READ); assert sel.select(15),label
    value=proc.stdout.readline().strip(); assert value,label; return value
def snapshot_owned(stage):
    parents={int(a):int(b) for a,b in (q.split() for q in S.check_output(['ps','-e','-o','pid=,ppid='],text=True).splitlines())}; tree={os.getpid()}
    while True:
        more={pid for pid,ppid in parents.items() if ppid in tree}-tree
        if not more: break
        tree.update(more)
    for pid in tree-{os.getpid()}:
        assert str(pid) not in protected
        try: identities[str(pid)]=identity(pid)
        except (FileNotFoundError,ProcessLookupError): pass
    (work/('owned-'+stage+'.json')).write_text(json.dumps(list(identities.values()),indent=2))
def pump():
    context=GLib.MainContext.default()
    for _ in range(100):
        if not context.pending(): break
        context.iteration(False)
def wait(predicate,label):
    deadline=time.monotonic()+15
    while time.monotonic()<deadline:
        if 'GLib' in globals(): pump()
        result=predicate()
        if result: return result
        time.sleep(.1)
    raise AssertionError(label)
def visit(node,predicate):
    try:
        if predicate(node): return node
        for child in node:
            if child:
                found=visit(child,predicate)
                if found: return found
    except Exception: pass
    return None
def application_node():
    return next((q for q in pyatspi.Registry.getDesktop(0) if q.get_process_id()==client.pid),None)
def named(name,role=None):
    app=application_node()
    return visit(app,lambda n:n.name==name and (role is None or n.getRole()==role)) if app else None
def rect(node):
    q=node.queryComponent().getExtents(pyatspi.DESKTOP_COORDS); return [q.x,q.y,q.width,q.height]
def event_received(event):
    try:
        app=event.source.getApplication()
        if app is None or app.get_process_id()!=client.pid: return
        q={'phase':phase,'monotonic':time.monotonic(),'type':event.type,'detail1':event.detail1,'detail2':event.detail2,'source_name':event.source.name,'source_role':event.source.getRoleName()}
        events.append(q); (work/'bridge-events.jsonl').open('a').write(json.dumps(q,ensure_ascii=False)+'\n')
    except Exception as error:
        (work/'bridge-event-errors.jsonl').open('a').write(json.dumps({'phase':phase,'type':event.type,'error':str(error)})+'\n')
def tree(label):
    rows=[]
    def walk(node,path):
        try:
            s=node.getState()
            try: bounds=rect(node)
            except NotImplementedError: bounds=None
            rows.append({'path':path,'role':node.getRoleName(),'name':node.name,'description':node.description,'visible':s.contains(pyatspi.STATE_VISIBLE),'showing':s.contains(pyatspi.STATE_SHOWING),'enabled':s.contains(pyatspi.STATE_ENABLED),'sensitive':s.contains(pyatspi.STATE_SENSITIVE),'selected':s.contains(pyatspi.STATE_SELECTED),'rect':bounds})
            for i,child in enumerate(node):
                if child: walk(child,path+[i])
        except Exception as error: rows.append({'path':path,'error':str(error)})
    app=application_node(); assert app is not None; walk(app,[])
    (work/(label+'.atspi.json')).write_text(json.dumps(rows,ensure_ascii=False,indent=2)); return rows
def capture(label):
    time.sleep(.2); image=ImageGrab.grab(xdisplay=display); image.save(work/(label+'.png')); return list(image.size)
def runtime(stage):
    proc=pathlib.Path('/proc')/str(client.pid)
    assert proc.joinpath('exe').resolve()==binary and sha(proc.joinpath('exe'))==sha(binary)
    libraries=sorted(set(q.split()[-1] for q in proc.joinpath('maps').read_text().splitlines() if '/libQt6' in q or '/plugins/platforms/' in q))
    assert any('/libQt6Widgets.so.6.5.3' in q for q in libraries) and any('/plugins/platforms/libqxcb.so' in q for q in libraries)
    assert all(pathlib.Path(q).is_relative_to(prefix) for q in libraries)
    (work/('runtime-'+stage+'.json')).write_text(json.dumps({'actual_process':identity(client.pid),'binary_sha256':sha(binary),'loaded_qt':[{'path':q,'sha256':sha(pathlib.Path(q))} for q in libraries],'qt_child_only_loader':True,'display':display,'requested_scale_factor':'1','private_bus':identity(private_bus.pid)},indent=2))
    snapshot_owned(stage)
try:
    work.mkdir(mode=0o700,parents=True)
    for key,directory in [('XDG_CONFIG_HOME','config'),('XDG_CACHE_HOME','cache'),('XDG_DATA_HOME','data'),('XDG_RUNTIME_DIR','runtime')]:
        (work/directory).mkdir(mode=0o700); os.environ[key]=str(work/directory)
    private_bus=S.Popen(['/usr/bin/dbus-daemon','--session','--nofork','--print-address=1','--nosyslog'],stdout=S.PIPE,stderr=(work/'dbus.log').open('w'),text=True); owned.append(private_bus)
    os.environ['DBUS_SESSION_BUS_ADDRESS']=line(private_bus,'owned private DBus address')
    xvfb=S.Popen(['/usr/bin/Xvfb','-displayfd','1','-screen','0','2400x1000x24','-nolisten','tcp'],stdout=S.PIPE,stderr=(work/'xvfb.log').open('w'),text=True); owned.append(xvfb)
    display=':'+line(xvfb,'owned Xvfb display'); os.environ['DISPLAY']=display
    with (work/'activation.log').open('w') as log: S.run(['/usr/bin/dbus-update-activation-environment','DISPLAY','XDG_RUNTIME_DIR','XDG_CONFIG_HOME','XDG_CACHE_HOME','XDG_DATA_HOME'],stdout=log,stderr=S.STDOUT,check=True)
    env=os.environ.copy(); env.update(LD_LIBRARY_PATH=str(prefix/'lib'),QT_PLUGIN_PATH=str(prefix/'plugins'),QT_QPA_PLATFORM='xcb',QT_FONT_DPI='96',QT_SCALE_FACTOR='1',QT_AUTO_SCREEN_SCALE_FACTOR='0',QT_ENABLE_HIGHDPI_SCALING='0',QT_LINUX_ACCESSIBILITY_ALWAYS_ON='1',QT_IM_MODULE='compose')
    client=S.Popen([str(binary)],stdout=(work/'standard-qt.log').open('w'),stderr=S.STDOUT,env=env); owned.append(client)
    import pyatspi
    from gi.repository import GLib
    pyatspi.Registry.registerEventListener(event_received,'object','window')
    wait(application_node,'standard Qt actual public accessible application')
    import dbus
    session=dbus.bus.BusConnection(os.environ['DBUS_SESSION_BUS_ADDRESS'])
    bus_object=session.get_object('org.a11y.Bus','/org/a11y/bus'); spi_address=str(bus_object.GetAddress(dbus_interface='org.a11y.Bus'))
    spi=dbus.bus.BusConnection(spi_address)
    def bus_pid(connection,name):
        return int(connection.get_object('org.freedesktop.DBus','/org/freedesktop/DBus').GetConnectionUnixProcessID(name,dbus_interface='org.freedesktop.DBus'))
    service_pids=[bus_pid(session,'org.a11y.Bus'),bus_pid(spi,'org.a11y.atspi.Registry')]
    for pid in service_pids:
        info=identity(pid); assert str(pid) not in protected and int(info['tick'])>=int(observer_identity['tick']); identities[str(pid)]=info
    (work/'owned-accessibility-services.json').write_text(json.dumps({'session_bus_services':service_pids,'identities':[identities[str(pid)] for pid in service_pids]},indent=2))
    x=C.CDLL('libX11.so.6'); xt=C.CDLL('libXtst.so.6'); x.XOpenDisplay.argtypes=[C.c_char_p]; x.XOpenDisplay.restype=C.c_void_p; d=x.XOpenDisplay(display.encode()); assert d
    for name,types,result in [('XRaiseWindow',[C.c_void_p,C.c_ulong],C.c_int),('XSetInputFocus',[C.c_void_p,C.c_ulong,C.c_int,C.c_ulong],C.c_int),('XFlush',[C.c_void_p],C.c_int)]:
        f=getattr(x,name); f.argtypes=types; f.restype=result
    xt.XTestFakeMotionEvent.argtypes=[C.c_void_p,C.c_int,C.c_int,C.c_int,C.c_ulong]; xt.XTestFakeButtonEvent.argtypes=[C.c_void_p,C.c_uint,C.c_int,C.c_ulong]
    phase='initial'; wait(lambda:named('标准Qt私人申请者 · 待审批',pyatspi.ROLE_LIST_ITEM),'initial actual private request Name')
    initial=tree('01-private-tabs-visible'); canvas=capture('01-private-tabs-visible-fullscreen'); runtime('initial')
    button=wait(lambda:named('模拟远端降为成员',pyatspi.ROLE_PUSH_BUTTON),'actual standard Qt UI hide button'); r=rect(button); assert r[2]>0 and r[3]>0
    windows=S.check_output(['xwininfo','-root','-tree'],text=True)
    line_window=next(q for q in windows.splitlines() if '"Standard Qt hidden tabs contract"' in q); window_id=int(re.search('0x[0-9a-f]+',line_window)[0],16)
    x.XRaiseWindow(d,window_id); x.XSetInputFocus(d,window_id,2,0); x.XFlush(d); time.sleep(.12)
    phase='hide-private-tabs'
    (work/'actions.jsonl').write_text(json.dumps({'input':'XTest physical UI click','public_role':button.getRoleName(),'public_name':button.name,'rect':r},ensure_ascii=False)+'\n')
    xt.XTestFakeMotionEvent(d,-1,round(r[0]+r[2]/2),round(r[1]+r[3]/2),0); xt.XTestFakeButtonEvent(d,1,1,0); xt.XTestFakeButtonEvent(d,1,0,0); x.XFlush(d)
    wait(lambda:named('当前权限：成员',pyatspi.ROLE_LABEL),'actual standard Qt hide callback finished')
    wait(lambda:not list(named('待处理入群申请',pyatspi.ROLE_LIST)),'actual native request model cleared')
    after=tree('02-private-tabs-hidden'); capture('02-private-tabs-hidden-fullscreen'); runtime('after-hide'); pump()
    private_tabs=[q for q in after if q.get('role')=='page tab' and q.get('name') in ['入群申请 (1)','管理']]
    standard_same=bool(private_tabs) and all(q['visible'] and q['showing'] and q['enabled'] and q['rect'][2:]==[0,0] for q in private_tabs)
    strict_ok=all(not q['visible'] and not q['showing'] for q in private_tabs)
    facts={'scope':'Standard Qt6.5.3 QTabWidget::setTabVisible(false), real xcb/private DBus/public active AT-SPI, no Chat business code or database.','binary':str(binary),'binary_sha256':sha(binary),'observer_sha256':sha(pathlib.Path(__file__)),'standard_cpp_sha256':sha(binary.parent/'standard_tabs.cpp'),'max_wait_seconds':15,'whole_canvas_pixels':canvas,'standard_same_as_chat_hidden_tab_state':standard_same,'hidden_private_tabs':private_tabs,'strict_hidden_tabs_not_exposed_pass':strict_ok,'request_rows_cleared':True,'private_applicant_name_after_hide_present':any('标准Qt私人申请者' in q.get('name','') for q in after),'live_hide_event_count':sum(q['phase']=='hide-private-tabs' for q in events),'no_manual_cache_clear':True,'no_QAccessible_setActive_or_private_widget_injection':True,'no_database':True,'scope_limits':'Pure standard Qt requested scale1; not actual Chat before/after, four DPI or Orca speech.'}
    (work/'actual-result.json').write_text(json.dumps(facts,ensure_ascii=False,indent=2))
    assert strict_ok,'Strict hidden-tab contract failed in pure standard Qt: '+json.dumps(private_tabs,ensure_ascii=False)
    exit_code=0
except BaseException as error:
    (work/'failure.json').write_text(json.dumps({'phase':phase,'type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()},ensure_ascii=False,indent=2))
    if 'display' in globals():
        try: capture('failure-fullscreen'); tree('failure')
        except Exception: pass
finally:
    if 'private_bus' in globals(): snapshot_owned('cleanup-before')
    for proc in reversed(owned):
        if proc.poll() is None:
            proc.terminate()
            try: proc.wait(timeout=15)
            except S.TimeoutExpired: proc.kill(); proc.wait(timeout=15)
    def still_own(info):
        try:
            now=identity(info['pid']); return now['tick']==info['tick'] and now['cmdline_hex']==info['cmdline_hex'] and now['state']!='Z'
        except (FileNotFoundError,ProcessLookupError): return False
    for info in reversed(list(identities.values())):
        if still_own(info): assert str(info['pid']) not in protected; os.kill(info['pid'],signal.SIGTERM)
    deadline=time.monotonic()+15
    while any(still_own(q) for q in identities.values()) and time.monotonic()<deadline: time.sleep(.1)
    for info in identities.values():
        if still_own(info): os.kill(info['pid'],signal.SIGKILL)
    gone=all(not still_own(q) for q in identities.values()); unchanged=all(identity(int(pid))['tick']==q['tick'] and identity(int(pid))['cmdline_hex']==q['cmdline_hex'] for pid,q in protected.items())
    source_end={path:sha(repo/path) for path in source_start}; source_unchanged=source_start==source_end
    (work/'source-inputs.json').write_text(json.dumps({'start':source_start,'end':source_end,'unchanged':source_unchanged},indent=2))
    (work/'cleanup.json').write_text(json.dumps({'workflow_exit':exit_code,'all_owned_gone':gone,'owned':[{'pid':proc.pid,'exit':proc.poll()} for proc in owned],'descendants_and_services':list(identities.values()),'protected_expected_and_unchanged':protected,'protected_unchanged':unchanged,'no_database_or_server_created':True,'source_unchanged':source_unchanged},indent=2))
    assert gone and unchanged and source_unchanged
    (work/'artifact-sha256.json').write_text(json.dumps({q.name:sha(q) for q in sorted(work.iterdir()) if q.is_file() and q.name!='artifact-sha256.json'},indent=2))
print(json.dumps({'status':'PASS' if exit_code==0 else 'FAIL','actual_exit':exit_code,'work':str(work)}),flush=True)
sys.exit(exit_code)
