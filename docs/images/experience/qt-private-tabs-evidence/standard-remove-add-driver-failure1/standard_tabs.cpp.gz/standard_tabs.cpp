#include <QApplication>
#include <QLabel>
#include <QListWidget>
#include <QPushButton>
#include <QTabWidget>
#include <QVBoxLayout>
#include <QWidget>
#include <iostream>

int main(int argc, char** argv)
{
    QApplication application(argc, argv);
    QWidget window;
    window.setWindowTitle(QStringLiteral("Standard Qt hidden tabs contract"));
    window.resize(1100, 740);
    auto* layout = new QVBoxLayout(&window);
    auto* version = new QLabel(QStringLiteral("标准 Qt %1 · QTabWidget 隐藏契约").arg(QString::fromLatin1(qVersion())), &window);
    layout->addWidget(version);
    auto* tabs = new QTabWidget(&window);
    tabs->setAccessibleName(QStringLiteral("标准群资料 tabs"));
    layout->addWidget(tabs, 1);
    auto* overview = new QWidget(tabs);
    auto* overviewLayout = new QVBoxLayout(overview);
    overviewLayout->addWidget(new QLabel(QStringLiteral("群资料公开页"), overview));
    tabs->addTab(overview, QStringLiteral("群资料"));
    auto* members = new QWidget(tabs);
    auto* membersLayout = new QVBoxLayout(members);
    auto* publicMembers = new QListWidget(members);
    publicMembers->setAccessibleName(QStringLiteral("公开群成员"));
    publicMembers->addItem(QStringLiteral("公开成员甲"));
    publicMembers->addItem(QStringLiteral("公开成员乙"));
    publicMembers->setCurrentRow(1);
    membersLayout->addWidget(publicMembers);
    tabs->addTab(members, QStringLiteral("成员"));
    auto* requestsPage = new QWidget(tabs);
    auto* requestsLayout = new QVBoxLayout(requestsPage);
    auto* requests = new QListWidget(requestsPage);
    requests->setAccessibleName(QStringLiteral("待处理入群申请"));
    auto* row = new QListWidgetItem(QStringLiteral("标准Qt私人申请者"), requests);
    row->setData(Qt::AccessibleTextRole, QStringLiteral("标准Qt私人申请者 · 待审批"));
    requestsLayout->addWidget(requests, 1);
    auto* accept = new QPushButton(QStringLiteral("通过申请"), requestsPage);
    auto* reject = new QPushButton(QStringLiteral("拒绝申请"), requestsPage);
    requestsLayout->addWidget(accept);
    requestsLayout->addWidget(reject);
    tabs->addTab(requestsPage, QStringLiteral("入群申请 (1)"));
    auto* management = new QWidget(tabs);
    auto* managementLayout = new QVBoxLayout(management);
    managementLayout->addWidget(new QLabel(QStringLiteral("管理私有页"), management));
    tabs->addTab(management, QStringLiteral("管理"));
    auto* status = new QLabel(QStringLiteral("当前权限：管理员"), &window);
    layout->addWidget(status);
    auto* lose = new QPushButton(QStringLiteral("模拟远端降为成员"), &window);
    layout->addWidget(lose);
    auto* restore = new QPushButton(QStringLiteral("恢复管理权限（可重复）"), &window);
    layout->addWidget(restore);
    QObject::connect(lose, &QPushButton::clicked, &window, [=] {
        if (tabs->indexOf(management) >= 0) { tabs->removeTab(tabs->indexOf(management)); }
        if (tabs->indexOf(requestsPage) >= 0) { tabs->removeTab(tabs->indexOf(requestsPage)); }
        requests->clear();
        accept->setEnabled(false);
        reject->setEnabled(false);
        accept->hide();
        reject->hide();
        status->setText(QStringLiteral("当前权限：成员"));
        lose->setEnabled(false);
    });
    QObject::connect(restore, &QPushButton::clicked, &window, [=] {
        if (tabs->indexOf(requestsPage) < 0) {
            tabs->addTab(requestsPage, QStringLiteral("入群申请 (%1)").arg(requests->count()));
        }
        if (tabs->indexOf(management) < 0) { tabs->addTab(management, QStringLiteral("管理")); }
        status->setText(QStringLiteral("当前权限：管理员"));
        lose->setEnabled(true);
    });
    tabs->setCurrentIndex(2);
    window.show();
    std::cout << "qt_runtime_version=" << qVersion() << "\n" << std::flush;
    return application.exec();
}
