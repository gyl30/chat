#!/usr/bin/env python3
"""Archive explicit Q35 scopes without configs/ELF; verify every byte and gzip roundtrip."""
import argparse
import gzip
import hashlib
import json
import pathlib
import shutil

REPO = pathlib.Path('/home/gyl/example/chat')
SCOPES = {
    'original-product-before': '/tmp/chat-q33-native-live-attempt3.JAH1dlZk',
    'standard-hide-driver-failure': '/tmp/chat-standard-qt-tabs.3nwzX8Jf',
    'standard-hide-contract-fail': '/tmp/chat-standard-qt-tabs-attempt2.hjnJNUKW',
    'standard-remove-add-driver-failure1': '/tmp/chat-standard-qt-remove-add.51P6nqRM',
    'standard-remove-add-driver-failure2': '/tmp/chat-standard-qt-remove-add-attempt2.EdbWSAYS',
    'standard-remove-add-contract-pass': '/tmp/chat-standard-qt-remove-add-attempt3.XLEahPLM',
    'permanent-same-fixture-red-green': '/tmp/chat-private-tabs-permanent.c6pTzeeO',
    'native-after-runner-pgenv-failure': '/tmp/chat-q35-native-private-tabs-after.E9wPEHTk',
    'native-after-runner-role-failure': '/tmp/chat-q35-native-private-tabs-after-attempt2.HIgXDeOB',
    'native-after-actual-pass': '/tmp/chat-q35-native-private-tabs-after-attempt3.LWBFq4d0',
}
SUFFIXES = {'.png', '.json', '.jsonl', '.txt', '.log', '.sha256', '.exit', '.py', '.cpp', '.hpp', '.diff'}
SECRET_KEYS = {'password', 'PGPASSWORD', 'password_hash', 'invite_token', 'token'}
SOURCES = {
    'qt/src/group_dialog.cpp': 'ab02ac28e55272cfa5d36f1381e0308d849ed8d59e744ae35e4cb8372bb0c830',
    'qt/src/group_dialog.hpp': 'ee392c52189a31d20f4a427600bda3fbabdcc0430bdd040baca781ef1e816f93',
    'qt/tests/ui_test.cpp': '01772f7278505fcc13afe6964ef31930d598fc1ce176504163329f288540ef30',
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def no_secret_json(value):
    if isinstance(value, dict):
        assert not any(k in SECRET_KEYS and v not in (None, '', [], {}) for k, v in value.items()), 'Secret-bearing JSON excluded; do not print its values'
        for child in value.values():
            no_secret_json(child)
    elif isinstance(value, list):
        for child in value:
            no_secret_json(child)


def selected_files(scope):
    # Deliberately flat root/run only; never copy config/cache/runtime/DB directories.
    for directory in (scope, scope / 'run'):
        if directory.is_dir():
            for path in sorted(directory.iterdir()):
                if path.is_file() and not path.is_symlink() and (path.suffix in SUFFIXES or path.name == 'run_permanent.sh'):
                    yield path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--destination', required=True, type=pathlib.Path)
    args = parser.parse_args()
    dest = args.destination.resolve()
    assert dest.is_relative_to(REPO / 'docs/images/experience')
    assert not dest.exists(), 'Never overwrite an existing archive'
    before = {p: digest((REPO / p).read_bytes()) for p in SOURCES}
    assert before == SOURCES, 'Source freeze changed; stop archive'
    planned = []
    scope_checks = {}
    for label, raw_scope in SCOPES.items():
        scope = pathlib.Path(raw_scope)
        assert scope.is_dir()
        manifest = scope / 'run/artifact-sha256.json'
        if manifest.is_file():
            entries = json.loads(manifest.read_text())
            for name, expected in entries.items():
                assert pathlib.PurePath(name).name == name
                assert digest((manifest.parent / name).read_bytes()) == expected
            scope_checks[label] = {'original_manifest_entries': len(entries), 'mismatches': 0}
        else:
            scope_checks[label] = {'original_manifest_absent': True, 'boundary': 'Original driver failed before final manifest or this is the independent permanent scope; retained as-is, never manufactured PASS.'}
        for path in selected_files(scope):
            data = path.read_bytes()
            assert not data.startswith(b'\x7fELF'), 'No binary in repository archive'
            if path.suffix == '.json':
                no_secret_json(json.loads(data))
            elif path.suffix == '.jsonl':
                for line in data.splitlines():
                    if line.strip():
                        no_secret_json(json.loads(line))
            relative = path.relative_to(scope)
            out = dest / label / relative
            if path.suffix != '.png':
                out = out.with_name(out.name + '.gz')
            planned.append((label, path, out, data))
    dest.mkdir(parents=True)
    records = []
    for label, source, out, data in planned:
        out.parent.mkdir(parents=True, exist_ok=True)
        if source.suffix == '.png':
            shutil.copyfile(source, out)
        else:
            out.write_bytes(gzip.compress(data, compresslevel=9, mtime=0))
        stored = out.read_bytes()
        restored = stored if source.suffix == '.png' else gzip.decompress(stored)
        assert restored == data and digest(source.read_bytes()) == digest(data)
        records.append({'scope': label, 'source': str(source), 'source_sha256': digest(data), 'archive': str(out.relative_to(dest)), 'archive_sha256': digest(stored), 'decompressed_sha256': digest(restored), 'original_bytes': len(data), 'archive_bytes': len(stored)})
    after = {p: digest((REPO / p).read_bytes()) for p in SOURCES}
    assert before == after == SOURCES
    proof = {'status': 'PASS', 'scope_checks': scope_checks, 'files': records, 'file_count': len(records), 'original_png_count': sum(q['archive'].endswith('.png') for q in records), 'source_start': before, 'source_end': after, 'source_unchanged': True, 'roundtrip_and_source_sha_mismatches': 0, 'boundary': '10 isolated scopes remain independent; first native runner failed before creating DB/Qt, second runner failed only at incorrect ROLE_ENTRY. Tree snapshot errors are 0, event-observer read errors are 61, not zero. No secrets config, caches, SDK, compiled binaries or unrecorded directories copied. Existing raw evidence is not changed/deleted.'}
    (dest / 'archive-proof.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'status': 'PASS', 'destination': str(dest), 'file_count': len(records), 'original_png_count': proof['original_png_count'], 'source_unchanged': True, 'roundtrip_mismatches': 0}, ensure_ascii=False))


if __name__ == '__main__':
    main()
