import hashlib,json,subprocess,sys
from pathlib import Path

directory=Path('/tmp/chat-qt-matrix-driver.2y82nyss')
driver=directory/'dpi.py'
digest='0a79f50ab2aec968d0c42b0eb32003a740d33a2e5fcaea076f7ee412de383d30'
plan=directory/'pages.jsonl'
assert hashlib.sha256(driver.read_bytes()).hexdigest()==digest
assert hashlib.sha256(plan.read_bytes()).hexdigest()=='65bca18ee2b9e7de2d832b6fc7ebe2ac75c0dda85a0341f481f9b98c150bb76d'
outcomes=[]
for label,scale in [('100-r2',1),('150',1.5),('200',2)]:
    scope='/tmp/chat-daily-native-qt-scale'+label+'-2y82nyss'
    assert not Path(scope).exists()
    with plan.open('rb') as commands,(directory/('scale'+label+'.log')).open('wb') as output:
        result=subprocess.run([sys.executable,'-u',str(driver),'--execute','--reviewed-sha',digest,
            '--scope',scope,'--port','18962','--scale',str(scale)],stdin=commands,stdout=output,stderr=subprocess.STDOUT)
    outcomes.append({'scope':scope,'scale':scale,'actual_exit':result.returncode})
    (directory/'matrix-exits.json').write_text(json.dumps(outcomes,indent=2))
    print(json.dumps(outcomes[-1]),flush=True)
    if result.returncode: sys.exit(result.returncode)
